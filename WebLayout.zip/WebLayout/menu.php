<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="view1.css">
</head>
<body>
    <div class="container">
        <h1>Menu</h1>
        <ul>
            <li><a href="Enrollment.html.php">Enroll on a Course</a></li>
            <li> <a href="EnrollClients.php">Cancel an Enrollment</a></li>
            <li><a href="trainingForm.html">Add a new Training Course</a></li>
            <li><a href="">Delete a training Course</a></li>
            <li><a href="ViewCourses.php">Ammen / View a Training Course</a></li>
        </ul> 
</body>