<!DOCTYPE html>
<head>
    Edit/view training course
</head>
<?php include 'ViewCourses.php'; ?>
<script>


function check(li){
    		confirm("you clicked " + li.textContent);
		}

</script>